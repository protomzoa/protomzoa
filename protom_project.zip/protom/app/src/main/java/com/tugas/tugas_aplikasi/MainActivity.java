package com.tugas.tugas_aplikasi;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private FusedLocationProviderClient fusedLocationClient;
    private SensorManager sensorManager;
    private TextView accelerometerText;
    private TextView gpsText;
    Button saveButton;
    Button loadButton;
    Button cameraButton;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize views

        EditText inputText = findViewById(R.id.inputText);
        accelerometerText = findViewById(R.id.accelerometerText);
        gpsText = findViewById(R.id.gpsText);
        saveButton = findViewById(R.id.saveButton);
        loadButton = findViewById(R.id.loadButton);
        cameraButton = findViewById(R.id.cameraButton);

        // Shared Preferences setup
        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        inputText.setText(sharedPreferences.getString("pesanTersimpan",""));
        saveButton.setOnClickListener(v -> {
            String text = inputText.getText().toString();
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("pesanTersimpan", text);
            editor.apply();
            Toast.makeText(this, "Data Tersimpan!", Toast.LENGTH_SHORT).show();
        });

        loadButton.setOnClickListener(v -> {
            inputText.setText(sharedPreferences.getString("pesanTersimpan",""));
            Toast.makeText(this, "Data Dipulihkan!", Toast.LENGTH_SHORT).show();
        });

        // GPS setup
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        } else {
            getLocation();
        }

        // Accelerometer setup
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        Sensor accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }

        // Camera setup
        cameraButton.setOnClickListener(v -> {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
            } else {
                Toast.makeText(this, "Kamera tidak tersedia", Toast.LENGTH_SHORT).show();
            }
        });

        //setup Perulangan/looping
        TextView loopText = findViewById(R.id.loopText);
        StringBuilder loopOutput = new StringBuilder();
        loopOutput.append("Perulangan 1 sampai 10\n");
        for (int i = 1; i <= 10; i++) {
            loopOutput.append("Perulangan nomor: ").append(i).append("\n");
        }
        loopText.setText(loopOutput.toString());
    }

    private void getLocation() {
        //cek terlebih dahulu perijinan akses lokasi
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }

        //mendapatkan lokasi saat ini
        fusedLocationClient.getLastLocation().addOnSuccessListener(this, new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null) {
                    gpsText.setText("Lokasi GPS saat ini \nLatitude: " + location.getLatitude() + ", Longitude: " + location.getLongitude()); //memasukan hasil lokasi saat ini kedalam textview
                } else {
                    gpsText.setText("tidak dapat mendapatkan lokasi terkini");
                }
            }
        });
    }

    //fungsi yang dipanggil ketika sensor bekerja
    @Override
    public void onSensorChanged(SensorEvent event) {
        float x = event.values[0];
        float y = event.values[1];
        float z = event.values[2];
        accelerometerText.setText("goyangkan hp untuk menjalankan accelerometer \nX: " + x + ", Y: " + y + ", Z: " + z);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not used
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
    }


    //jika perijinan akses lokasi di setujui pengguna
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            getLocation();
        }
    }
}